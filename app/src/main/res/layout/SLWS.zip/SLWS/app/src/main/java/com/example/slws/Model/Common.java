package com.example.slws.Model;

public class Common {

    public static final int NUM_OF_COLUMN = 3;
}
